using System.Text;
using System.Text.Encodings.Web;
using WordReader.Services.WordExtractor;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();

builder.Services.AddScoped<ITextExtractor, InteropTextExtractor>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();

RunWordExtractor(app);

app.Run();

static void RunWordExtractor(WebApplication app)
{
    using var scoped = app.Services.CreateScope();
    var extractor = scoped.ServiceProvider.GetService<ITextExtractor>();
    var document = extractor.Extract(@"C:\raha_part 02_08-02-1404-mini.docx");

    foreach (var page in document.Pages)
    {
        Console.WriteLine($"Page: {page.PageNumber}");

        foreach (var paragraph in page.Paragraphs)
        {
            Console.WriteLine($"  Paragraph: {paragraph.ParagraphIndex}");
            Console.WriteLine($"  Style: {paragraph.StyleName}");
            Console.WriteLine($"  Text: {paragraph.Text}");
            Console.WriteLine();
        }
    }
    var str = System.Text.Json.JsonSerializer.Serialize(document.Pages.SelectMany(p=> p.Paragraphs.Select(p=> new { p.Text ,p.PageNumber,p.ParagraphIndex,p.StyleName})),options:new System.Text.Json.JsonSerializerOptions
    {

        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    });

    File.WriteAllText(
        "output.txt",
        str,
        new UTF8Encoding(false)); // UTF-8 ???? BOM
}